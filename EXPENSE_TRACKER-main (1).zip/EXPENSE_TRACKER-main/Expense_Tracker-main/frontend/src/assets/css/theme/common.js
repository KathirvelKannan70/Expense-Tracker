export const center = {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",

}